import mysql.connector
class bbdd:
    def conexion_bbdd():
        conexion = mysql.connector.connect(
            host="bxlfjozyadylicrojiil-mysql.services.clever-cloud.com",
            user="uvbui3pydp3dtywa",
            password="RlFkyyTF3rhbD2AppQHU",
            database="bxlfjozyadylicrojiil"
        )
        print(conexion)
        return conexion

    def consultar_usuario(conexion):
            # Crear un cursor para ejecutar consultas
        cursor = conexion.cursor()

        # Definir la consulta SQL
        consulta = "SELECT Id_usuario FROM Usuarios WHERE Correo = %s"

        # Supongamos que el correo electrónico está almacenado en la variable correo
        correo = "ivangarciamoriones23@gmail.com"

        # Ejecutar la consulta con el correo como parámetro
        cursor.execute(consulta, (correo,))

        # Obtener el resultado de la consulta
        resultado = cursor.fetchone()

        # Cerrar el cursor y la conexión
        cursor.close()
        conexion.close()

        # Si se encontró un resultado, imprimir el ID de usuario
        if resultado:
            Id_usuario = resultado[0]
            print("El ID de usuario para el correo {} es: {}".format(correo, Id_usuario))
            return Id_usuario
            
        else:
            print("No se encontró ningún usuario con el correo {}".format(correo))
            return None
        
    def insertar_jugador_bbdd(lista_datos_jugadores, conexion):
        try:
            # Crear un cursor para ejecutar consultas SQL
            cursor = conexion.cursor()

            for datos_jugador in lista_datos_jugadores:
                # Definir la consulta SQL para verificar la existencia del jugador por nombre y apellido
                consulta_existencia = "SELECT * FROM Jugadores WHERE Nombre = %s AND Apellido = %s"

                # Parámetros de la consulta
                parametros = (
                    datos_jugador["nombre"],
                    datos_jugador["apellido"]
                )

                # Ejecutar la consulta para verificar la existencia del jugador
                cursor.execute(consulta_existencia, parametros)

                # Obtener el resultado de la consulta
                resultado = cursor.fetchone()

                # Verificar si el jugador ya existe en la tabla
                if resultado:
                    print("El jugador ya existe en la base de datos. No es necesario insertarlo.")
                else:
                    # Construir la consulta SQL
                    placeholders_jornadas = ', '.join(['%s'] * 38)  # Asumiendo que tienes hasta 38 jornadas
                    consulta_insercion = f"INSERT INTO Jugadores (Nombre, Apellido, Equipo, Posicion, Valor, Puntos_totales, Media_total, Partidos, Goles, Tarjetas, Media_en_casa, Media_visitante, Valor_subido_bajado, Mercado, Puntos_predicción, Valor_predicción, Jornada_1, Jornada_2, Jornada_3, Jornada_4, Jornada_5, Jornada_6, Jornada_7, Jornada_8, Jornada_9, Jornada_10, Jornada_11, Jornada_12, Jornada_13, Jornada_14, Jornada_15, Jornada_16, Jornada_17, Jornada_18, Jornada_19, Jornada_20, Jornada_21, Jornada_22, Jornada_23, Jornada_24, Jornada_25, Jornada_26, Jornada_27, Jornada_28, Jornada_29, Jornada_30, Jornada_31, Jornada_32, Jornada_33, Jornada_34, Jornada_35, Jornada_36, Jornada_37, Jornada_38) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, {placeholders_jornadas})"
                    # Parámetros de la consulta de inserción
                    parametros_insercion = (
                        datos_jugador["nombre"],
                        datos_jugador["apellido"],
                        datos_jugador["nombre_equipo"],
                        datos_jugador["posicion"],
                        datos_jugador["valor"],
                        datos_jugador["puntos_totales"],
                        datos_jugador["media"],
                        datos_jugador["partidos"],
                        datos_jugador["goles"],
                        datos_jugador["tarjetas"],
                        datos_jugador["media_en_casa"],
                        datos_jugador["media_fuera"],
                        datos_jugador["valor_subido_bajado"],
                        datos_jugador["mercado"],
                        datos_jugador["puntos_predicción"],
                        datos_jugador["valor_predicción"],
                        datos_jugador["jornada_1"],
                        datos_jugador["jornada_2"],
                        datos_jugador["jornada_3"],
                        datos_jugador["jornada_4"],
                        datos_jugador["jornada_5"],
                        datos_jugador["jornada_6"],
                        datos_jugador["jornada_7"],
                        datos_jugador["jornada_8"],
                        datos_jugador["jornada_9"],
                        datos_jugador["jornada_10"],
                        datos_jugador["jornada_11"],
                        datos_jugador["jornada_12"],
                        datos_jugador["jornada_13"],
                        datos_jugador["jornada_14"],
                        datos_jugador["jornada_15"],
                        datos_jugador["jornada_16"],
                        datos_jugador["jornada_17"],
                        datos_jugador["jornada_18"],
                        datos_jugador["jornada_19"],
                        datos_jugador["jornada_20"],
                        datos_jugador["jornada_21"],
                        datos_jugador["jornada_22"],
                        datos_jugador["jornada_23"],
                        datos_jugador["jornada_24"],
                        datos_jugador["jornada_25"],
                        datos_jugador["jornada_26"],
                        datos_jugador["jornada_27"],
                        datos_jugador["jornada_28"],
                        datos_jugador["jornada_29"],
                        datos_jugador["jornada_30"],
                        datos_jugador["jornada_31"],
                        datos_jugador["jornada_32"],
                        datos_jugador["jornada_33"],
                        datos_jugador["jornada_34"],
                        datos_jugador["jornada_35"],
                        datos_jugador["jornada_36"],
                        datos_jugador["jornada_37"],
                        datos_jugador["jornada_38"]
                    )

                    # Ejecutar la consulta para insertar datos
                    cursor.execute(consulta_insercion, parametros_insercion)

                    # Confirmar la transacción
                    conexion.commit()
                    print("Datos del jugador insertados correctamente.")

        except mysql.connector.Error as error:
            print("Error al conectar a la base de datos:", error)



    
    def cerrar_conexion(conexion):

        if conexion.cursor:
            conexion.cursor.close()
        if conexion:
            conexion.close()

    def insertar_arbitro_bbdd(driver, datos_arbitros):
        try:
            conexion = mysql.connector.connect(
                host="bxlfjozyadylicrojiil-mysql.services.clever-cloud.com",
                user="uvbui3pydp3dtywa",
                password="RlFkyyTF3rhbD2AppQHU",
                database="bxlfjozyadylicrojiil"
            )

            cursor = conexion.cursor()

            query = """
            INSERT INTO Arbitros (arbitro, partidos_jugados, penaltis_pitados, promedio_penalti, tarjetas_amarillas, promedio_amarilla, tarjetas_rojas, promedio_roja, doble_amarilla, promedio_doble_amarilla)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """

            for datos in datos_arbitros:
                cursor.execute(query, (
                    datos['arbitro'],
                    datos['partidos_jugados'],
                    datos['penaltis_pitados'],
                    datos['p_penalti'],
                    datos['tarjetas_amarillas'],
                    datos['p_amarilla'],
                    datos['tarjetas_rojas'],
                    datos['p_roja'],
                    datos['doble_amarilla'],
                    datos['p_doble_amarilla']
                ))

            conexion.commit()
            print("Datos insertados exitosamente en la base de datos")
        except mysql.connector.Error as e:
            print(f"Error al guardar los datos en la base de datos: {e}")
        finally:
            if conexion.is_connected():
                cursor.close()
                conexion.close()
                print("Conexión a la base de datos cerrada")