from jugadores import jugadores
from bbdd import bbdd
from arbitro import arbitro


class main:
    def main_jugadores():
        # Obtener una instancia de ChromeDriver
        
        driver = jugadores.chromedriver()

        # Navegar a la URL
        driver.get('https://mister.mundodeportivo.com')

        # Ocultar anuncios
        jugadores.hide_ads(driver)

        # Aceptar cookies
        jugadores.aceptar_cookies(driver)

        # Iniciar sesión o registro, si es necesario
        jugadores.iniciar_sesion(driver)

        conexion = bbdd.conexion_bbdd()

        bbdd.consultar_usuario(conexion)

        #jugadores.link_jugadores(driver)

        #jugadores.datos_jugadores(driver)

        bbdd.insertar_jugador_bbdd(jugadores.datos_jugadores(driver), bbdd.conexion_bbdd())

          # Obtener la conexión a la base de datos
        
        bbdd.cerrar_conexion(conexion)  # Cerrar la conexión


        # Cerrar el navegador al finalizar
        driver.quit()


    def main_arbitros():
        # Obtener una instancia de ChromeDriver
        driver = arbitro.chromedriver()

        # Navegar a la URL
        driver.get('https://es.besoccer.com/competicion/arbitros/primera')

        arbitro.hide_ads(driver)

        arbitro.aceptar_cookies_besoccer(driver)

        arbitro.obtener_datos_arbitros(driver)

        bbdd.conexion_bbdd()

        bbdd.insertar_arbitro_bbdd(arbitro.obtener_datos_arbitros(driver), bbdd.conexion_bbdd())


        


if __name__ == "__main__":
    main.main_jugadores()
    #main.main_arbitros()

